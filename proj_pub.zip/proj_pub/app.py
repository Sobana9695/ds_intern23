import pandas as pd
from PIL import Image
import streamlit as st
#st.set_page_config(layout="wide")

# Load the dataset
data = pd.read_csv(r'D:\DSintern_23\proj_pub\resources\data\pub.csv')
image = Image.open(r"D:\DSintern_23\proj_pub\resources\images\pub1.jpg")

total_pubs = len(data)
postcodes = len(data['PostCode'].unique())
local_authorities = len(data['Local_Authority'].unique())

# Create the Home Page
def home_page():
    st.markdown("<h1 style='color: blue'>Welcome to the Pub finder App</h1>", unsafe_allow_html=True)
    
    st.image(image, width= 750)
    st.write('### :green[Total number of pubs in the dataset:]', total_pubs)
    

# Run the app
if __name__ == '__main__':
    home_page()